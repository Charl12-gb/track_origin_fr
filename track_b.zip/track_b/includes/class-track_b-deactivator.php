<?php

/**
 * Fired during plugin deactivation
 *
 * @link       GBOYOU
 * @since      1.0.0
 *
 * @package    Track_b
 * @subpackage Track_b/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Track_b
 * @subpackage Track_b/includes
 * @author     GBOYOU <gboyoucharles.tech@gmail.com>
 */
class Track_b_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
