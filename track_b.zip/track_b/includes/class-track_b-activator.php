<?php

/**
 * Fired during plugin activation
 *
 * @link       GBOYOU
 * @since      1.0.0
 *
 * @package    Track_b
 * @subpackage Track_b/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Track_b
 * @subpackage Track_b/includes
 * @author     GBOYOU <gboyoucharles.tech@gmail.com>
 */
class Track_b_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		// Clear the permalinks after the post type has been registered.
		flush_rewrite_rules(); 
	}

}
