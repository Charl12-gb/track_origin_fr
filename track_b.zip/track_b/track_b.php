<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              GBOYOU
 * @since             1.0.0
 * @package           Track_b
 *
 * @wordpress-plugin
 * Plugin Name:       Track-B
 * Plugin URI:        orion.com
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            GBOYOU
 * Author URI:        GBOYOU
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       track_b
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'TRACK_B_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-track_b-activator.php
 */
function activate_track_b() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-track_b-activator.php';
	Track_b_Activator::activate();
}


/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-track_b-deactivator.php
 */
function deactivate_track_b() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-track_b-deactivator.php';
	Track_b_Deactivator::deactivate();
}

/*
 * On ajoute un nouveau statut de post &quot;en cours de livraison&quot; dans WordPress
 */
function msk_create_being_delivered_status_in_wc() {
	register_post_status(
		'wc-new-track',
		array(
			'label' => __('New order', 'uno'),
			'public'                    => true,
			'exclude_from_search'       => false,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop('New order <span class="count">(%s)</span>', 'New order <span class="count">(%s)</span>', 'uno')
		)
	);
}
add_action( 'init', 'msk_create_being_delivered_status_in_wc' );


/*
 * On insère ce nouveau statut dans la liste des statuts utilisés par WooCommerce
 */
function msk_add_being_delivered_status_to_wc($order_statuses) {
	$new_statuses_array = array();

	foreach ($order_statuses as $key => $status) {
		$new_statuses_array[$key] = $status;
		if ('wc-processing' === $key) $new_statuses_array['wc-new-track'] = __('New order', 'uno');
	}

	return $new_statuses_array;
}
add_filter('wc_order_statuses', 'msk_add_being_delivered_status_to_wc');

function msk_create_being_delivered_status() {
	register_post_status(
		'wc-received',
		array(
			'label' => __('Received', 'un'),
			'public'                    => true,
			'exclude_from_search'       => false,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop('Received <span class="count">(%s)</span>', 'Received <span class="count">(%s)</span>', 'un')
		)
	);
}
add_action( 'init', 'msk_create_being_delivered_status' );


/*
 * On insère ce nouveau statut dans la liste des statuts utilisés par WooCommerce
 */
function msk_add_being_delivered_status($order_statuses) {
	$new_statuses_array = array();

	foreach ($order_statuses as $key => $status) {
		$new_statuses_array[$key] = $status;
		if ('wc-processing' === $key) $new_statuses_array['wc-received'] = __('Received', 'un');
	}

	return $new_statuses_array;
}
add_filter('wc_order_statuses', 'msk_add_being_delivered_status');


function msk_create_being_delivered() {
	register_post_status(
		'wc-confirmed',
		array(
			'label' => __('Confirmed', 'u'),
			'public'                    => true,
			'exclude_from_search'       => false,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop('Confirmed <span class="count">(%s)</span>', 'Confirmed <span class="count">(%s)</span>', 'u')
		)
	);
}
add_action( 'init', 'msk_create_being_delivered' );


/*
 * On insère ce nouveau statut dans la liste des statuts utilisés par WooCommerce
 */
function msk_add_being_delivered($order_statuses) {
	$new_statuses_array = array();

	foreach ($order_statuses as $key => $status) {
		$new_statuses_array[$key] = $status;
		if ('wc-processing' === $key) $new_statuses_array['wc-confirmed'] = __('Confirmed', 'u');
	}

	return $new_statuses_array;
}
add_filter('wc_order_statuses', 'msk_add_being_delivered');


require_once plugin_dir_path( __FILE__ ) . 'admin/class-track-config.php';
require_once plugin_dir_path( __FILE__ ) . 'public/track_modif_insc.php';
require_once plugin_dir_path( __FILE__ ) . 'function.php';


register_activation_hook( __FILE__, 'activate_track_b' );
register_deactivation_hook( __FILE__, 'deactivate_track_b' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-track_b.php';

	/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_track_b() {
	
	$plugin = new Track_b();
	$plugin->run();
	
}
run_track_b();