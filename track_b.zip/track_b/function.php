<?php

use Automattic\WooCommerce\Blocks\Integrations\IntegrationRegistry;
/**
 * Récupérarion du carrier_code grace au numéro de suivi
 */
function identification($num, $key){
    /**
     * Get api key url https://my.trackingmore.com/get_apikey.php
     * Documentation url https://www.trackingmore.com/api-index.html
     */
    
    # Introduce file class auto loading
    require_once(dirname(__FILE__)."/Init.class.php");

    \APITracking\Api::setApiKey($key);

    $response = \APITracking\Detect::post($num);

    $vars = json_decode($response, true);
    foreach ($vars as $var) {
        if(isset($var[0]['code'])){
            try{
                $carrier_code = $var[0]['code'];
            }catch(Exception $e){
                die('Vérifier votre code suivi et réessayer. : Merci');
            }
        }
        else{
            $carrier_code = null;
        }
    }
    return $carrier_code;
}

/**
 * Obtenir l'id du dernier post
 */
function get_the_last_post():int {
	global $wpdb;
	return $wpdb->get_var("SELECT MAX( ID ) FROM $wpdb->posts");
}

/**
 * Vérifier si le numéro de suivi envoyer par le client n'est pas déjà envoyé
 */
function verification($code_suivi):int{
    
    global $wpdb;
    $post_type ="shop_order";
    $post_author_id = get_current_user_id();
    $verification_sqls = $wpdb->get_results( "SELECT ID FROM $wpdb->posts WHERE post_type = '$post_type' AND post_author = '$post_author_id' AND post_name = '$code_suivi' " );
    $i = 0;
    foreach ( $verification_sqls as $verification_sql ){
        $i = $i + 1;
    }
    return $i;
}

/**
 * Redirection
 */
if(isset($_POST['track_redirect'])){  
    require_once( ABSPATH . 'wp-includes/pluggable.php' );
    $url_redirection = sanitize_text_field($_POST['track_redirect']);
    wp_redirect($url_redirection);
    exit;
}

/**
 * Mise à jour de la bd
 */
function requete_db(){
    global $wpdb;
	$post_author = get_current_user_id();

    if(isset( $_REQUEST['track_delete'] ) ){
        $del_id = sanitize_text_field( $_REQUEST['track_delete'] );
        $wpdb->delete(
			"{$wpdb->prefix}posts",
			[ 'ID' => $del_id ],
			[ '%d' ]
		);
		$wpdb->delete(
			"{$wpdb->prefix}woocommerce_order_itemmeta",
			[ 'order_item_id' => $del_id ],
			[ '%d' ]
		);
		$wpdb->delete(
			"{$wpdb->prefix}woocommerce_order_items",
			[ 'order_id' => $del_id ],
			[ '%d' ]
		);
        $wpdb->delete(
			"{$wpdb->prefix}wc_order_stats",
			[ 'order_id' => $del_id ],
			[ '%d' ]
		);
    }
    
    
    if(isset($_POST['numero'])){
        $num = sanitize_text_field( $_POST['numero'] );
        $string1 = str_replace(' ', '', $num);
        $string = str_replace('-','', $string1);
        $numero = strtoupper($string);
        $key = sanitize_text_field( $_POST['key'] );

        $carrier_code = identification($numero, $key);
        //$carrier_code = 'fedex';
        if($carrier_code == ''){ 
            echo '<p style="text-align: center;">Vérifier votre code suivi et réessayer. : Merci</p>';
            unset($_POST['numero']);
        }else{
            
            $trouver = verification($numero);
            if($trouver > 0){
                echo '<p style="text-align: center;">Ce numéro de suivi est en cours de traitement. : Merci</p>';
                unset($_POST['numero']);
            }else{
                $post_author_id = get_current_user_id();
    
                $new_post = array(
                    'post_title' => $numero,
                    'comment_status' => 'closed',
                    'ping_status' => 'closed',
                    'post_status' => 'wc-new-track',
                    'post_date' => date('Y-m-d H:i:s'),
                    'post_author' => $post_author_id,
                    'post_type' => 'shop_order',
                    'comment_count' => 1,
                    'post_category' => array(0)
                );
                $post_id = wp_insert_post($new_post);
    
                $postid = get_the_last_post() ;
                
                wc_update_order_item_meta( $postid , '_line_total' , $meta_value = 1 , $prev_value = '' ); 
                wc_update_order_item_meta( $postid , '_qty' , $meta_value = 1 , $prev_value = '' ); 
                wc_update_order_item_meta( $postid , '_product_id' , $meta_value = 1 , $prev_value = '' );
     
                $order_item_id = wc_add_order_item( $postid, array(
                    'order_item_name' => $numero,
                    'order_item_type' => $carrier_code,
               ));
            }
      
        }
        
        unset($_POST['numero']);
        afficherinfo_track();
    }
    else
    {
        if($post_author == 0){
            $track_redirect = '';
                ?>
                <html>
                <head>
                    <script>    
                        setTimeout('document.getElementById(\'form\').submit();', 0);
                    </script>
                </head>
                <body>
                    <h3>Veillez-vous connectez d'abord.</h3>
                    <form action="" method="post" id="form">
                        <input id="track_redirect" name="track_redirect" type="hidden" value="<?php echo get_permalink ( wc_get_page_id( 'myaccount' ) );?>">
                    </form>
                </body>
                </html>
                <?php
        }else{
            $post_type ="shop_order";
            $post_author = get_current_user_id();
            $table_name1 = $wpdb->prefix . 'woocommerce_order_items';
            $table_name2 = $wpdb->posts;
            $fivesdrafts = $wpdb->get_results( "SELECT ID,order_id, order_item_name, order_item_type FROM $table_name1, $table_name2  WHERE $table_name1.order_id = $table_name2.ID AND post_type = '$post_type' AND post_author = $post_author " );
            
            //Recuperation de la cle API
            $desc = 'tracking_more';
            $api_keys = $wpdb->get_row( "SELECT meta_value FROM $wpdb->termmeta WHERE meta_key = '$desc'" );
            if(isset($api_keys->meta_value)){
                $key_api = $api_keys->meta_value;
            }else{
                $key_api = '';
            }
            
            ?>
            <div class="post-inner thin ">
            <div class="entry-content">
                <?php
                    if($key_api == ''){
                        ?>
                        <p>The page you are requesting is unavailable at the moment please contact the administrator.</p>
                        <?php
                    }else{
                        ?>
                        <form action="" method="POST" class="comment-form">
                        <?php wp_nonce_field('track', 'cagnotte-verif'); ?>
                            <h4>Ajouter un numéro</h4>
                            <p>Track allows you to track your packages between Benin and China.</p>
                            <p>
                                <label for="don">Numéro de suivi : </label>
                                <input id="numero" type="text" name="numero" placeholder="123456789ABC" />
                                <input id="key" name="key" type="hidden" value="<?php echo $key_api; ?>">
                            </p>
                            <p>
                                <input id="submit" type="submit" name="cagnote-don-envoi" id="submit" class="submit" value="Envoyer" />
                            </p>
                        </form>
                            <table class="responsive-table">
                            <tr>
                                <th>
                                    Numéro
                                </th>
                                <th>
                                    Code
                                </th>
                                <th>
                                    Action
                                </th>
                            <tr>
                        <?php
                        
                        foreach ( $fivesdrafts as $fivesdraft ) {
                        ?>
                            <tr>
                                <td>
                                    <?php 
                                    echo($fivesdraft->order_item_name); 
                                    ?>
                                </td>
                                <td>
                                    <?php 
                                    echo($fivesdraft->order_item_type); 
                                    ?>
                                </td>
                                <td>
                                    <?php $de = sprintf( '<a href="?track_delete=%s"><button style="padding:5px;">Delete</button></a>', absint( $fivesdraft->order_id ) ); 
                                    echo $de;
                                    ?>
                                </td>
                            </tr>    
                        <?php
                        }
                        ?>
                        </table>
                        <?php
                        if($fivesdrafts == null){
                            ?>
                                <p style="text-align: center;">
                                    You have not submitted any tracking number. <br>
                                    Send Tracking Number Now
                                </p>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            <?php
            }

        }
    }
}

function afficherinfo_track() {

    $var = wp_nonce_field('faire-don', 'cagnotte-verif'); 
    $monTexte = requete_db();
    
    return $monTexte;
}
add_shortcode('track_code', 'afficherinfo_track');