<?php
if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class Customers_List extends WP_List_Table {

	/** Class constructor */
	public function __construct() {

		parent::__construct( [
			'singular' => __( 'Customer', 'sp' ), //singular name of the listed records
			'plural'   => __( 'Customers', 'sp' ), //plural name of the listed records
			'ajax'     => false //does this table support ajax?
		] );

	}


	/**
	 * Retrieve customers data from the database
	 *
	 * @param int $per_page
	 * @param int $page_number
	 *
	 * @return mixed
	 */
	public static function get_customers( $per_page = 5, $page_number = 1 ) {

		global $wpdb;

		$table_track1 = $wpdb->prefix. 'posts';
		$table_track2 = $wpdb->prefix. 'woocommerce_order_items';
		$sql = "SELECT * FROM $table_track1, $table_track2 WHERE $table_track2.order_id = $table_track1.ID AND $table_track1.post_type = 'shop_order' AND post_status = 'wc-received' ";
		//$sql = "SELECT * FROM {$wpdb->prefix}customers";

		if ( ! empty( $_REQUEST['orderby'] ) ) {
			$sql .= ' ORDER BY ' . esc_sql( $_REQUEST['orderby'] );
			$sql .= ! empty( $_REQUEST['order'] ) ? ' ' . esc_sql( $_REQUEST['order'] ) : ' ASC';
		}

		$sql .= " LIMIT $per_page";
		$sql .= ' OFFSET ' . ( $page_number - 1 ) * $per_page;


		$result = $wpdb->get_results( $sql, 'ARRAY_A' );

		return $result;
	}

	/**
	 * Delete a customer record.
	 *
	 * @param int $id customer ID
	 */
	public static function delete_customer( $id ) {
		global $wpdb;

		$wpdb->delete(
			"{$wpdb->prefix}posts",
			[ 'ID' => $id ],
			[ '%d' ]
		);
		$wpdb->delete(
			"{$wpdb->prefix}woocommerce_order_itemmeta",
			[ 'order_item_id' => $id ],
			[ '%d' ]
		);
		$wpdb->delete(
			"{$wpdb->prefix}woocommerce_order_items",
			[ 'order_id' => $id ],
			[ '%d' ]
		);
		$wpdb->delete(
			"{$wpdb->prefix}wc_order_stats",
			[ 'order_id' => $id ],
			[ '%d' ]
		);
	}


	/**
	 * Returns the count of records in the database.
	 *
	 * @return null|string
	 */
	public static function record_count() {
		global $wpdb;

		$sql = "SELECT COUNT(*) FROM {$wpdb->prefix}posts WHERE post_type = 'shop_order' AND post_status = 'wc-received'";

		return $wpdb->get_var( $sql );
	}


	/** Text displayed when no customer data is available */
	public function no_items() {
		_e( 'No customers avaliable.', 'sp' );
	}


	/**
	 * Render a column when no column specific method exist.
	 *
	 * @param array $item
	 * @param string $column_name
	 *
	 * @return mixed
	 */
	public function column_default( $item, $column_name ) {
		switch ( $column_name ) {
			case 'order_item_type':
				return $item[ $column_name ];
			default:
				return print_r( $item, true ); //Show the whole array for troubleshooting purposes
		}
	}

	/**
	 * Render the bulk edit checkbox
	 *
	 * @param array $item
	 *
	 * @return string
	 */
	function column_cb( $item ) {
		return sprintf(
			'<input type="checkbox" name="bulk-delete[]" value="%s" />', $item['ID']
		);
	}

	/**
	 * Method for name column
	 *
	 * @param array $item an array of DB data
	 *
	 * @return string
	 */
	function column_name( $item ) {

		$delete_nonce = wp_create_nonce( 'sp_delete_customer' );
		$var_edit = '
			<script type="text/javascript">
			function hideThis(_div){
				var obj = document.getElementById(_div);
				if(obj.style.display == "block")
					obj.style.display = "none";
				else
					obj.style.display = "block";
			}
			</script>
			<style>
			#form%s{
				display:none;
			 }
			</style>
			
			<div id="form%s" colspan="4">
			<form enctype="multipart/form-data" method="POST" action="">
				<label>Poid: </label> 
				<input name ="poid_track"type="number" step="any" min="0" />
				<label>Type: </label>
				<select name="type_track" type="select">
					<option valeur="normal">Normal</option>
					<option valeur="special">Special</option>
				</select>
				<br><br>
				<label>Image: </label>
				<input type="url" name="image_url_track" id="image_url_track">
				<input type="hidden" name="id_prod_track" id="id_prod_track" value ="%s" >
				<input type="submit" value="Valider"/>
				<br><br>
			</form>
			</div>
			<input style="color: blue;" type="button" value="Options" onclick="hideThis(\'form%s\')" />
		';

		$d = sprintf($var_edit,  absint( $item['ID'] ),  absint( $item['ID'] ),  absint( $item['ID'] ),  absint( $item['ID'] ),  absint( $item['ID'] ));
		$title = '<strong>' . $item['order_item_name'] . '</strong>';

		$actions = [
			'delete' => sprintf( '<a href="?page=%s&action=%s&customer=%s&_wpnonce=%s">Delete</a>', esc_attr( $_REQUEST['page'] ), 'delete', absint( $item['ID'] ), $delete_nonce ),
			//'detail' => sprintf( '<a href="?customer=%s">Details</a>', absint( $item['ID'] ) )
		];

		return $title . $this->row_actions( $actions ) . $d ;
	}

	/**
	 *  Associative array of columns
	 * 
	 * @return array
	 */
	function get_columns() {
		$columns = [
			'cb'      => '<input type="checkbox" />',
			'name'    => __( 'Track number', 'sp' ),
			'order_item_type'    => __( 'Carriere code', 'sp' ),
		];

		return $columns;
	}

	/**
	 * Returns an associative array containing the bulk action
	 *
	 * @return array
	 */
	public function get_bulk_actions() {
		$actions = [
			'bulk-delete' => 'Delete'
		];

		return $actions;
	}

	/**
 * Vérifier si le produit est déjà  livré
 */
public function commande_livre(){

    # Récuperation de la clé API
    global $wpdb;
    $desc = 'tracking_more';
    $api_keys = $wpdb->get_row( "SELECT meta_value FROM $wpdb->termmeta WHERE meta_key = '$desc'" );
    if(isset($api_keys->meta_value)){
		$key_api = $api_keys->meta_value;
	}else{
		$key_api = '';
	}
    
    # Introduce file class auto loading
    require_once(dirname(__FILE__)."../../Init.class.php");
	
    \APITracking\Api::setApiKey($key_api);
	
    $table_name1 = $wpdb->prefix . 'woocommerce_order_items';    
    $table_name2 = $wpdb->posts;
    $post_status = 'wc-new-track';
	$post_type ="shop_order";
    $undelivered_parcel_numbers = $wpdb->get_results( "SELECT ID,order_id, order_item_name, order_item_type FROM $table_name1, $table_name2  WHERE $table_name1.order_id = $table_name2.ID AND post_type = '$post_type' AND post_status = '$post_status' " );
    
    foreach ( $undelivered_parcel_numbers as $undelivered_parcel_number ) {
		
		//require_once plugin_dir_path( __FILE__ ) . '../../../../wp-includes/post.php';
		require_once( ABSPATH . 'wp-includes/post.ph' );

        # Get a tracking number of real-time query result data
        $data = ["tracking_number" => "$undelivered_parcel_number->order_item_name", "carrier_code" => "$undelivered_parcel_number->order_item_type"];
        $response = \APITracking\Realtime::post($data);
        $vars = json_decode($response, true);

        if(isset($vars['data']['items'][0]['status'])){
            try{
                $parcel_status = $vars['data']['items'][0]['status'];
            }
            catch(Exception $e){}
        }
        else{
            $parcel_status = null;
        }

        #passer à la mise à jour de la table (changer l'état de la commande)
        if($parcel_status == 'delivered'){
			$id_post = $undelivered_parcel_number->ID;
			$post_status_new = 'wc-received';
			$my_post = array(
				'ID'           => $id_post,
				'post_status'   => $post_status_new,
			);
			
		// Update the post into the database
			wp_update_post( $my_post );
        }
    }
    //print_r($vars['data']['items'][0]['status']);
    //return $parcel_status;
}


	/**
	 * Handles data query and filter, sorting, and pagination.
	 */
	public function prepare_items() {

		$this->_column_headers = $this->get_column_info();

		/** Process bulk action */
		$this->process_bulk_action();

		$per_page     = $this->get_items_per_page( 'customers_per_page', 5 );
		$current_page = $this->get_pagenum();
		$total_items  = self::record_count();

		$this->set_pagination_args( [
			'total_items' => $total_items, //WE have to calculate the total number of items
			'per_page'    => $per_page //WE have to determine how many items to show on a page
		] );

		$this->items = self::get_customers( $per_page, $current_page );
	}

	public function process_bulk_action() {

		//Detect when a bulk action is being triggered...
		if ( 'delete' === $this->current_action() ) {

			// In our file that handles the request, verify the nonce.
			$nonce = esc_attr( $_REQUEST['_wpnonce'] );

			if ( ! wp_verify_nonce( $nonce, 'sp_delete_customer' ) ) {
				die( 'Go get a life script kiddies' );
			}
			else {
				self::delete_customer( absint( $_GET['customer'] ) );
			}

		}

		// If the delete bulk action is triggered
		if ( ( isset( $_POST['action'] ) && $_POST['action'] == 'bulk-delete' )
		     || ( isset( $_POST['action2'] ) && $_POST['action2'] == 'bulk-delete' )
		) {

			$delete_ids = esc_sql( $_POST['bulk-delete'] );

			// loop over the array of record IDs and delete them
			foreach ( $delete_ids as $id ) {
				self::delete_customer( $id );

			}

			// esc_url_raw() is used to prevent converting ampersand in url to "#038;"
		        // add_query_arg() return the current url
		        wp_redirect( esc_url_raw(add_query_arg()) );
			exit;
		}
	}

}


class SP_Plugin {

	// class instance
	static $instance;

	// customer WP_List_Table object
	public $customers_obj;

	// class constructor
	public function __construct() {
		add_filter( 'set-screen-option', [ __CLASS__, 'set_screen' ], 10, 3 );
		add_action( 'admin_menu', [ $this, 'plugin_menu' ] );
	}


	public static function set_screen( $status, $option, $value ) {
		return $value;
	}

	public function plugin_menu() {

		$hook = add_menu_page(
			'Track',
			'Track',
			'manage_options',
			'wp_list_table_class',
			[ $this, 'plugin_settings_page' ]
		);

		add_action( "load-$hook", [ $this, 'screen_option' ] );

	}


	/**
	 * Plugin settings page
	 */
	public function plugin_settings_page() {
		global $wpdb;
		/**
		 * call update data key
		 */
		if(isset( $_POST['track_key'] ) && ! empty( $_POST['track_key'] ) ) {
			$track_key = sanitize_text_field( $_POST['track_key'] );
			update_term_meta( $term_id = 1 , 'tracking_more' , $track_key , $prev_value  =  ''  );
		}

		$time_track_verify = date('H');

		if( isset( $_POST['poid_track'] ) && isset( $_POST['type_track'] ) && !empty($_POST['poid_track']) && !empty($_POST['type_track']) ){
			$poid_coli = sanitize_text_field($_POST['poid_track']) ;
			$type_coli = sanitize_text_field($_POST['type_track']) ;
			$post_id = sanitize_text_field($_POST['id_prod_track']) ;
			$image_url = sanitize_text_field( $_POST['image_url_track'] ) ;

			$post_status_new = 'wc-confirmed';
			$my_post = array(
				'ID'           => $post_id,
				'post_status'   => $post_status_new,
				'post_content' => $image_url,
			);
			// Update the post into the database
			wp_update_post( $my_post );
			wc_update_order_item_meta( $post_id , '_package_type' , $type_coli , $prev_value = '' ); 
            wc_update_order_item_meta( $post_id , '_package_weight' , $poid_coli , $prev_value = '' ); 
		}

		if(isset( $_REQUEST['track_delete_t'] ) ){
			$id_track_del = sanitize_text_field($_POST['track_delete_t']) ;
			$this->customers_obj->delete_customer($id_track_del);
		}

		if($time_track_verify == '12' || $time_track_verify == '15'){
			$this->customers_obj->commande_livre();
		}

		// include_once( ABSPATH . 'wp-cron.php' );
		// add_filter('track_schedul', 'interval_track');

		// function interval_track( $schedules ) {
		// 	$schedules['5seconds'] = array( 
		// 		'interval' => 5,
		// 		'display' => __('Every 5 Seconds') 
		// 	);
		// 	return $schedules; 
		// }

		// add_action( 'track_hook', 'fichier' );
		// if( !wp_next_scheduled( 'track_hook' ) ) {
		// 	wp_schedule_event( time(), '5seconds', 'track_hook' );
		// }
		// function fichier(){
		// 	file_put_contents('exemple.txt', 'Ecriture dans un fichier');
		// }

		?>
		<div class="wrap">
			<h2>Liste des track soumise</h2>
			<script>
				var nb = 1800 ;
				window.setTimeout(" window.location.reload();", 1000*nb, "JavaScript");
			</script>
			<div id="poststuff">
				<div id="post-body" class="metabox-holder columns-2">
					<div id="post-body-content">
						<?php
						include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
						if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
							
							//Vérifier si une clé existe
							$desc = 'tracking_more';
							$api_keys = $wpdb->get_row( "SELECT meta_value FROM $wpdb->termmeta WHERE meta_key = '$desc'" );
            				if(isset($api_keys->meta_value)){
								$key_api = $api_keys->meta_value;
							}else{
								$key_api = '';
							}
							if($key_api == ''){
								?>
								<hr>
								<div class="meta-box-sortables ui-sortable" style="text-align:center;">
									<h3 style="text-decoration:underline;">Before you can continue please enter your API key</strong></h3>
									<form method="post" action="#">
										<p>API key : <input type="text" id="track_key" name="track_key" /></p>
										<p><input type="submit" value="Envoyer" /></p>
									</form>
								</div>
								<hr>
								<?php
							}
							else{
								?>
								<hr>
								<div class="meta-box-sortables ui-sortable" style="font-size: 15px;">
									<form method="post" action="#">
										<p>API key : <br><input type="text" id="track_key" name="track_key" /></p>
										<p><input type="submit" value="Envoyer" /></p>
									</form>   
									<p">API Key actuel : <br> <strong><?php echo$key_api ?></strong></p>
								</div>
								<hr>
								<hr>
								<div class="meta-box-sortables ui-sortable">
									<form method="post">
										<?php 
											$this->customers_obj->prepare_items();
											$this->customers_obj->display(); 
										?>
									</form>
								</div>
								<hr><hr>

								<div class="meta-box-sortables ui-sortable">
									<script type="text/javascript">
									function hideThis(_div){
										var obj = document.getElementById(_div);
										if(obj.style.display == "block")
											obj.style.display = "none";
										else
											obj.style.display = "block";
									}
									</script>
									<style>
									#confirmed, #new_track{
										display:none;
									}
									</style>
									
									<div>
										<?php
											$post_type = "shop_order";
											$post_status = "wc-confirmed" ;
											$table_name1 = $wpdb->prefix . 'woocommerce_order_items';
											$table_name2 = $wpdb->posts;
											$infor_colis = $wpdb->get_results( "SELECT ID,order_id, post_author, order_item_name, order_item_type, post_content FROM $table_name1, $table_name2  WHERE $table_name1.order_id = $table_name2.ID AND post_type = '$post_type' AND post_status = 'wc-confirmed' ORDER BY ID DESC LIMIT 0,20" );

											?>
											<div id="confirmed">
											<h3 style="text-decoration: underline">Les colis confirmés</h3>
											<?php
											foreach ( $infor_colis as $infor_coli ) {
												$id_pro_meta = $infor_coli->ID;
												$id_user_meta = $infor_coli->post_author; 
												$delete_nonce = wp_create_nonce( 'sp_delete_customer' );
												?>
											
													</style>
														<table id="<?php echo $id_pro_meta; ?>" style="width: 100%; font-size:18px; display:none;">
															<tr>
																<td colspan="4" style="text-decoration: underline"><h4>Colis <?php echo $infor_coli->ID ;?> </h4></td>
															</tr>
															<tr>
																<!-- <td><img src="<?php //echo $infor_coli->post_content;  ?>" /></td> -->
																<td>Numéro de suivi : <strong> <?php echo $infor_coli->order_item_name ;?></strong></td>
																<td>Code : <strong> <?php echo $infor_coli->order_item_type ;?></strong></td>
																<td>Type : <strong> <?php if (isset(wc_get_order_item_meta($id_pro_meta, '_package_type', false)[0])) echo(wc_get_order_item_meta($id_pro_meta, '_package_type', false)[0]) ;?></strong></td>
																<td>Poids : <strong> <?php if (isset(wc_get_order_item_meta($id_pro_meta, '_package_weight', false)[0])) echo(wc_get_order_item_meta($id_pro_meta, '_package_weight', false)[0] .' kg') ;?></strong></td>
															</tr>
															<tr>
																<td colspan="4" style="text-decoration: underline"><h4>Information du l'envoyeur</h4></td>
															</tr>
															<tr>
																<!-- <td><img src="<?php //echo $infor_coli->post_content;  ?>" /></td> -->
																<td>Nom  : <strong> <?php if(isset(get_user_meta( $id_user_meta , 'first_name', false )[0])) echo get_user_meta( $id_user_meta , 'first_name', false )[0]; echo ' '; echo get_user_meta( $id_user_meta , 'last_name', false )[0] ;?></strong></td>
																<td>Téléphone <strong> <?php if(isset(get_user_meta( $id_user_meta , 'billing_phone', false )[0])) echo '<a href="tel:'. get_user_meta( $id_user_meta , 'billing_phone', false )[0].'">'.get_user_meta( $id_user_meta , 'billing_phone', false )[0].'</a>' ;?></strong></td>
																<td>
																	<form action="" method="post" id="form">
																		<input id="track_delete_t" name="track_delete_t" type="hidden" value="<?php echo $id_pro_meta ;?>">
																		<input style="color: red;" type="submit" value="Supprimer">
																	</form>
																</td>
															</tr>
														</table>
														<input style="color: blue;" type="button" value="commande <?php  echo $id_pro_meta ;?>" onclick="hideThis(<?php echo $id_pro_meta ;?>)" />
												<?php
											}
											?>
											<hr>
													</div>
											<?php
											$post_type = "shop_order";
											$table_name1 = $wpdb->prefix . 'woocommerce_order_items';
											$table_name2 = $wpdb->posts;
											$infor_colis_news = $wpdb->get_results( "SELECT ID,order_id, order_item_name, order_item_type FROM $table_name1, $table_name2  WHERE $table_name1.order_id = $table_name2.ID AND post_type = '$post_type' AND post_status = 'wc-new-track' ORDER BY ID DESC LIMIT 0,20" );
											
											?>
												<div id="new_track">
												<hr><hr>
												<h3 style="text-decoration: underline">Les nouveaux colis</h3>
											<?php
											foreach ( $infor_colis_news as $infor_colis_new ) {
												$id_pro_meta = $infor_colis_new->ID;
												?>
														<table id="<?php echo $id_pro_meta; ?>" style="width: 100%; font-size:18px; display:none;">
															<tr>
																<td>
																	<p>
																		Numéro de suivi : <strong> <?php echo $infor_colis_new->order_item_name ;?></strong>
																	</p>
																	<p>
																		Code : <strong> <?php echo $infor_colis_new->order_item_type ;?></strong>
																	</p>
																</td>
											
															</tr>
															<tr>
															<td>
																	<form action="" method="post" id="form">
																		<input id="track_delete_t" name="track_delete_t" type="hidden" value="<?php echo $id_pro_meta ;?>">
																		<input style="color: red;" type="submit" value="Supprimer">
																	</form>
																</td>
															</tr>
														</table>
														<input style="color: blue;" type="button" value="commande <?php  echo $id_pro_meta ;?>" onclick="hideThis(<?php echo $id_pro_meta ;?>)" />
													
												<?php
											}
										?>
										</div>
									</div>
									<input style="color: blue;" type="button" value="Afficher les commandes confirmés" onclick="hideThis('confirmed')" />
									<input style="color: blue;" type="button" value="Liste des nouvelles commandes" onclick="hideThis('new_track')" />
								</div>
								<?php
							}
						}
						else {
						?>
							<div class="meta-box-sortables ui-sortable" style="text-align:center;">
								<h3>Woocommerce extension is not installed.<strong> <a href="plugin-install.php">Click here to install.</a> </strong></h3>
							</div>
						<?php
						}
						?>
					</div>
				</div>
				<br class="clear">
			</div>
		</div>
	<?php
	}

	/**
	 * Screen options
	 */
	public function screen_option() {

		$option = 'per_page';
		$args   = [
			'label'   => 'Customers',
			'default' => 5,
			'option'  => 'customers_per_page'
		];

		add_screen_option( $option, $args );

		$this->customers_obj = new Customers_List();
	}


	/** Singleton instance */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

}


add_action( 'plugins_loaded', function () {
	SP_Plugin::get_instance();
} );
